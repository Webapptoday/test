# YouMatter Presentation Outline (10 minutes)

- Topic followed & Fair Use observed (see Works Cited).
- Clear structure: Learn / Resources / Appointments / Community / Blog / Stories / About.
- Accessibility: skip link, labels, landmarks, responsive layout.
- Demo: book appointment (.ics), create forum post & chat message.
- Judges' Q&A: privacy (browser-only), cross-browser tests, deployment plan (GitHub Pages).

Timing: ≤3 min setup, ≤10 min presentation.
