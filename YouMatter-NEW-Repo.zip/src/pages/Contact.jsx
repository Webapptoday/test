
import React from 'react'
export default function Contact(){
  return (<section>
    <h1>Contact</h1>
    <p>Email: <a href="mailto:team@yumatter.example">team@yumatter.example</a></p>
  </section>)
}
